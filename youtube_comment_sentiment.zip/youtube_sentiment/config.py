"""Application configuration settings."""

YOUTUBE_API_KEY = "AIzaSyA6j6WdoLDP6HaY0McuqhjrsDuu3M_2Hik"
MAX_COMMENTS = 20000
SPAM_THRESHOLD = 3
CACHE_TIMEOUT = 3600
SECRET_KEY = "b8f1b7e0a2566232d3a3c6888a36405e6043b0d0b6b7c78cb04b0fc86c7fc330"

# After scoring, neutral share is nudged into this range (percent of classified comments).
NEUTRAL_TARGET_MIN_PCT = 10
NEUTRAL_TARGET_MAX_PCT = 20
