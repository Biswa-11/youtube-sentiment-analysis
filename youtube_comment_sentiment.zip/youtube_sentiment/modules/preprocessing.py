"""Lightweight text preprocessing for sentiment analysis."""

from __future__ import annotations

import re

URL_RE = re.compile(r"https?://\S+|www\.\S+")
MULTI_SPACE_RE = re.compile(r"\s+")


def clean_comment_text(text: str) -> str:
    """
    Apply minimal cleaning while preserving sentiment cues.

    Does not remove or normalize negation words (not, never, no), emojis,
    punctuation, or intensifiers — only strips URLs and collapses whitespace so
    downstream VADER / DistilBERT retain informal and emotional signals.
    """
    cleaned = (text or "").strip()
    if not cleaned:
        return ""

    cleaned = URL_RE.sub(" ", cleaned)
    cleaned = MULTI_SPACE_RE.sub(" ", cleaned).strip()
    return cleaned
