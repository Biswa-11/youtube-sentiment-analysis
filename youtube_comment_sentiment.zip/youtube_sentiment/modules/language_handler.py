"""Language detection and translation helpers."""

from __future__ import annotations

from functools import lru_cache

from googletrans import Translator
from langdetect import LangDetectException, detect

_translator = Translator()

# ISO 639-1: Odia is `or`. AnalysisService routes `or` through Marian
# opus-mt-or-en; see modules.local_translator.SUPPORTED.


@lru_cache(maxsize=2048)
def detect_and_translate(text: str) -> dict[str, str]:
    """
    Detect language and translate text to English when needed.

    For Odia and other codes backed by local Marian models in AnalysisService,
    prefer the main pipeline (langdetect + modules.local_translator) so GPU
    opus-mt-or-en is used instead of this online fallback.

    Args:
        text: Input comment text.

    Returns:
        Dictionary containing original, translated, and language code.
    """
    cleaned = (text or "").strip()
    if not cleaned:
        return {"original": "", "translated": "", "language": "unknown"}

    try:
        language = detect(cleaned)
    except LangDetectException:
        language = "unknown"

    translated = cleaned
    if language not in {"en", "unknown"}:
        try:
            translated = _translator.translate(cleaned, dest="en").text
        except Exception:
            translated = cleaned

    return {"original": cleaned, "translated": translated, "language": language}
