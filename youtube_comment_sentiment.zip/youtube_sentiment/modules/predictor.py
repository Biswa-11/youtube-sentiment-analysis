"""Sentiment summary helpers and placeholder prediction hooks."""

from __future__ import annotations

from typing import Any

# If the gap between the highest and second-highest category shares is below this,
# overall sentiment is treated as ambiguous (NEUTRAL).
TOP_TWO_GAP_PCT = 5.0


def overall_sentiment_from_percentages(
    positive_percent: float,
    negative_percent: float,
    neutral_percent: float,
) -> str:
    """
    Derive overall label from category percentages.

    Rules:
    - If neutral share > 50%, overall is NEUTRAL.
    - If (max share - second share) < TOP_TWO_GAP_PCT, overall is NEUTRAL.
    - Else if positive wins both pairwise comparisons vs negative and neutral → POSITIVE.
    - Else if negative wins both pairwise comparisons → NEGATIVE.
    - Otherwise NEUTRAL.
    """
    p_pct = float(positive_percent)
    n_pct = float(negative_percent)
    u_pct = float(neutral_percent)

    if u_pct > 50.0:
        return "NEUTRAL"

    sorted_pcts = sorted((p_pct, n_pct, u_pct), reverse=True)
    if sorted_pcts[0] - sorted_pcts[1] < TOP_TWO_GAP_PCT:
        return "NEUTRAL"

    if p_pct > n_pct and p_pct > u_pct:
        return "POSITIVE"
    if n_pct > p_pct and n_pct > u_pct:
        return "NEGATIVE"
    return "NEUTRAL"


def predict_box_office(features: dict[str, Any]) -> dict[str, Any]:
    """
    Placeholder for future box office prediction model.

    Args:
        features: Input feature payload.

    Returns:
        Placeholder response indicating feature is not implemented.
    """
    return {
        "status": "not_implemented",
        "message": "Box office prediction is a placeholder in this version.",
        "input_features": features,
    }
